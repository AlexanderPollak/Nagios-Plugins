To install PERCCLI, perform the following steps:
1. To install the perccli RPM, run the rpm -ivh <perccli-x.xx-x.noarch.rpm> command.
2. To upgrade the perccli RPM, run the rpm -Uvh <perccli-x.xx-x.noarch.rpm> command.

For Ubuntu installations perform the following:

sudo apt-get install alien
sudo alien <perccli-x.xx-x.noarch.rpm>
sudo dpkg -i <perccli-x.xx-x.noarch.deb>
